[
  { "id": 1, "nome": "João" },
  { "id": 2, "nome": "Maria" }
]